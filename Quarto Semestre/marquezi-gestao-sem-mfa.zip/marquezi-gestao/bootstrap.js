"use strict";

(() => {
  const loginForm = document.querySelector("#loginForm");
  const toast = document.querySelector("#toast");
  let applicationLoading = false;

  function message(text) {
    toast.textContent = text;
    toast.className = "show";
    window.setTimeout(() => (toast.className = ""), 7000);
  }

  async function post(path, body) {
    const response = await fetch("/api" + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const result = await response.json();
    if (!response.ok)
      throw new Error(result.error || "Não foi possível concluir a operação.");
    return result;
  }

  function loadApplication() {
    if (applicationLoading) return;
    applicationLoading = true;
    const script = document.createElement("script");
    script.src = "/assets/application.js";
    script.addEventListener("error", () => {
      applicationLoading = false;
      message("Não foi possível carregar a área autenticada.");
    });
    document.head.append(script);
  }

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const button = event.submitter;
    if (button) button.disabled = true;
    try {
      await post("/login", Object.fromEntries(new FormData(loginForm)));
      loginForm.reset();
      loadApplication();
    } catch (error) {
      message(error.message);
    } finally {
      if (button) button.disabled = false;
    }
  });

  async function restoreSession() {
    try {
      let response = await fetch("/api/me", {
        headers: { Accept: "application/json" },
        cache: "no-store",
      });
      if (response.status === 401) {
        const refreshed = await post("/refresh", {});
        if (refreshed.csrf)
          response = await fetch("/api/me", {
            headers: { Accept: "application/json" },
            cache: "no-store",
          });
      }
      if (response.ok) loadApplication();
    } catch {
      // A tela de login permanece disponível quando a sessão não pode ser renovada.
    }
  }
  restoreSession();
})();
