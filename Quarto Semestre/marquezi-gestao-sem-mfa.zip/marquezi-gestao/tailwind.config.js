import plugin from "tailwindcss/plugin";

// As cores apontam para as variáveis de style.css, então tema escuro e
// alto contraste continuam funcionando sem duplicar paleta.
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./bootstrap.js", "./app.js"],
  corePlugins: { preflight: false }, // style.css já faz o reset
  theme: {
    extend: {
      colors: {
        ink: "var(--ink)",
        muted: "var(--muted)",
        line: "var(--line)",
        surface: "var(--surface)",
        soft: "var(--surface-soft)",
        teal: "var(--teal)",
        mint: "var(--mint)",
        orange: "var(--orange)",
        danger: "var(--danger)",
      },
      fontFamily: { sans: ['"DM Sans"', "system-ui", "sans-serif"] },
      keyframes: {
        rise: {
          from: { opacity: "0", transform: "translateY(10px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        pop: {
          from: { opacity: "0", transform: "scale(.96)" },
          to: { opacity: "1", transform: "scale(1)" },
        },
        shimmer: {
          from: { backgroundPosition: "200% 0" },
          to: { backgroundPosition: "-200% 0" },
        },
        beat: {
          "0%,100%": { boxShadow: "0 0 0 0 rgb(167 55 55 / .45)" },
          "50%": { boxShadow: "0 0 0 7px rgb(167 55 55 / 0)" },
        },
      },
      animation: {
        rise: "rise .5s cubic-bezier(.22,1,.36,1) both",
        pop: "pop .3s cubic-bezier(.22,1,.36,1) both",
        shimmer: "shimmer 1.8s linear infinite",
        beat: "beat 1.8s ease-in-out infinite",
      },
    },
  },
  plugins: [
    // Entrada escalonada dos filhos diretos de .stagger (só no painel).
    plugin(({ addUtilities }) => {
      const rules = {};
      for (let i = 1; i <= 10; i++)
        rules[`.stagger > :nth-child(${i})`] = { animationDelay: `${(i - 1) * 70}ms` };
      addUtilities(rules);
    }),
  ],
};
